<?php $__env->startSection('content'); ?>
    

    
    <div class="container-fluid bg-primary px-0 px-md-5 mb-5">
        <div class="row align-items-center px-3">
            <div class="col-lg-6 text-center text-lg-left">
                <h4 class="text-white mb-4 mt-5 mt-lg-0">Educación para el futuro: Tu camino hacia el éxito</h4>
                <h1 class="display-4 font-weight-bold text-white">Formación integral con valores y compromiso</h1>
                <a href="https://nicelocal.com.ve/caracas/education/liceo_nocturno_suroeste/"
                   class="btn btn-secondary mt-1 py-3 px-5">Ubicación</a>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <img class="img-fluid mt-5 header-logo" src="<?php echo e(asset('img/header.png')); ?>" alt="">
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('partials.facilities', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.classes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
        .header-logo {
            width: 80%; /* Ajustar el tamaño a un 50% del contenedor */
            max-width: 100%; /* Asegurarse de que no se extienda más allá del contenedor */
            height: auto; /* Mantener la proporción de aspecto */
            padding: 25px 0px 75px 90px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




    

    
    
        
            
                
                
                
                
                    
            
            
                
            
        
    

    
    
    
    
    




    



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aruizc01\Desktop\carnetizadorlnso-master\resources\views/sitio.blade.php ENDPATH**/ ?>