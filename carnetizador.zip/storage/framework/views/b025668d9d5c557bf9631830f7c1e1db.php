<nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0 px-lg-5">
    <a href="<?php echo e(url('/')); ?>" class="navbar-brand font-weight-bold text-secondary" style="font-size: 25px;">
        <img src="<?php echo e(asset('img/logo.ico')); ?>" alt="Logo" style="height: 40px; margin-right: 10px;">
        <span class="text-primary">Liceo SUR - OESTE</span>
    </a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
        <div class="navbar-nav font-weight-bold mx-auto py-0">
            <a href="<?php echo e(url('/')); ?>" class="nav-item nav-link active">Inicio</a>
            <a href="<?php echo e(url('/about')); ?>" class="nav-item nav-link">Nosotros</a>
            <a href="<?php echo e(url('/gallery')); ?>" class="nav-item nav-link">Galería</a>
            <a href="<?php echo e(url('/contact')); ?>" class="nav-item nav-link">Soporte</a>
            <a href="<?php echo e(route('students.create')); ?>" class="nav-item nav-link">Genera tu carné</a>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\aruizc01\Desktop\carnetizadorlnso-master\resources\views/partials/navbar.blade.php ENDPATH**/ ?>