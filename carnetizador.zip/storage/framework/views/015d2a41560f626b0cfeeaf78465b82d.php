<div class="container-fluid pt-5">
    <div class="container pb-3">
        <div class="row">
            <?php $__currentLoopData = [
                ['icon' => 'flaticon-050-fence', 'title' => 'Nuestra Misión Educativa', 'text' => 'Formamos bachilleres integrales, listos para el mundo laboral.'],
                ['icon' => 'flaticon-022-drum', 'title' => 'Flexibilidad y Apoyo', 'text' => 'Educación adaptada a tu ritmo de vida'],
                ['icon' => 'flaticon-030-crayons', 'title' => 'Desarrollo de Habilidades', 'text' => 'Potenciamos tus capacidades para el éxito profesional'],
                ['icon' => 'flaticon-017-toy-car', 'title' => 'Orientación Vocacional', 'text' => 'Te guiamos hacia tu futuro profesional'],
                ['icon' => 'flaticon-025-sandwich', 'title' => 'Educadores Comprometidos', 'text' => 'Contamos con un equipo docente experimentado y dedicado'],
                ['icon' => 'flaticon-047-backpack', 'title' => 'Tecnología e Innovación', 'text' => 'Utilizamos herramientas modernas para una educación efectiva'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 pb-1 <?php echo e($index >= 3 ? 'mt-4' : ''); ?>">
                    <div class="d-flex bg-light shadow-sm border-top rounded mb-4" style="padding: 30px; height: 100%;">
                        <i class="<?php echo e($item['icon']); ?> h1 font-weight-normal text-primary mb-3"></i>
                        <div class="pl-4">
                            <h4><?php echo e($item['title']); ?></h4>
                            <p class="m-0"><?php echo e($item['text']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>



<?php /**PATH C:\Users\aruizc01\carnetizador\resources\views/partials/facilities.blade.php ENDPATH**/ ?>