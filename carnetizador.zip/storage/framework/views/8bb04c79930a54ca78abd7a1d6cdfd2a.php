

<?php $__env->startSection('title', 'Vista Previa del Carnet'); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <div class="container" style="max-width: 90%; background-color: #f8f9fa; padding: 20px; border-radius: 8px;">
        <h2>Vista Previa del Carnet</h2>
        <hr size="8px" color="black" />
        <div class="row">
            <!-- Primera Columna: Información del Estudiante -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <p><strong>Nombre:</strong> <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></p>
                                <p><strong>Correo Electrónico:</strong> <?php echo e($student->email); ?></p>
                                <p><strong>Cargo:</strong> <?php echo e($student->rol); ?></p>
                                <p><strong>Año/Grado:</strong> <?php echo e($student->grade); ?></p>
                                <p><strong>Sección:</strong> <?php echo e($student->section); ?></p>
                            </div>
                            <div class="col-md-4 text-center">
                                <?php if($student->photo_path): ?>
                                    <img src="<?php echo e(Storage::url($student->photo_path)); ?>" alt="Foto del estudiante"
                                        class="img-thumbnail"
                                        style="max-width: 100%; max-height: 300px; margin-top: 10px; object-fit: cover;">
                                <?php else: ?>
                                    <p>No se proporcionó fotografía.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Segunda Columna: Botones de Acción y Miniatura del Carnet -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8 text-center">
                                <!-- Aquí va la miniatura del carnet generado -->
                                <img src="<?php echo e(asset('images/carnet_placeholder.png')); ?>" alt="Miniatura del Carnet"
                                    class="img-thumbnail" width="200">
                            </div>
                            <div class="col-md-4 text-center">
                                <!-- Botones de acción -->
                                <button onclick="window.print()" class="btn btn-primary" style="display: none;"
                                    id="printButton">Imprimir Carnet</button>
                                <a href="<?php echo e(route('students.approve', ['id' => $student->id])); ?>" class="btn btn-primary"
                                    id="confirmButton">Confirmar</a>
                                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-secondary"
                                    id="cancelButton">Cancelar</a>
                                <a href="<?php echo e(route('students.print', ['id' => $student->id])); ?>" class="btn btn-success"
                                    style="display: none;" id="printActionButton">Imprimir</a>
                                <a href="<?php echo e(route('students.email', ['id' => $student->id])); ?>" class="btn btn-info"
                                    style="display: none;" id="emailButton">Enviar por Correo</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const confirmButton = document.getElementById('confirmButton');
            const printButton = document.getElementById('printButton');
            const printActionButton = document.getElementById('printActionButton');
            const emailButton = document.getElementById('emailButton');
            const cancelButton = document.getElementById('cancelButton');

            confirmButton.addEventListener('click', function(event) {
                event.preventDefault();
                // Lógica para confirmar y mostrar botones
                printButton.style.display = 'block';
                printActionButton.style.display = 'block';
                emailButton.style.display = 'block';
                confirmButton.style.display = 'none';

                // Redirigir al enlace de confirmar
                window.location.href = confirmButton.getAttribute('href');
            });

            cancelButton.addEventListener('click', function(event) {
                event.preventDefault();
                // Lógica para cancelar y eliminar datos
                if (confirm(
                        '¿Estás seguro de que deseas cancelar? Se perderán todos los datos ingresados.')) {
                    window.location.href = cancelButton.getAttribute('href');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aruizc01\carnetizador\resources\views/students/preview.blade.php ENDPATH**/ ?>