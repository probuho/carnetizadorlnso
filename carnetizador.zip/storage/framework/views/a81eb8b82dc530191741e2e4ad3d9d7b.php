<!DOCTYPE html>
<html>
<head>
    <title>Nuevo reporte de soporte</title>
</head>
<body>
    <h1>Nuevo reporte de soporte</h1>
    <p>Nombre: <?php echo e($details['name']); ?></p>
    <p>Cédula: <?php echo e($details['cedula']); ?></p>
    <p>Correo: <?php echo e($details['email']); ?></p>
    <p>Reporte: <?php echo e($details['report']); ?></p>
    <?php if(!empty($details['screenshot'])): ?>
        <p>Captura de pantalla adjunta.</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\aruizc01\Desktop\carnetizadorlnso-master\resources\views/emails/support.blade.php ENDPATH**/ ?>