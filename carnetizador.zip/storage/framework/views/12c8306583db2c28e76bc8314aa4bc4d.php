<?php $__env->startSection('content'); ?>
<div>
    <h1>Nuevo reporte de soporte</h1>
    <p><strong>Nombre:</strong> <?php echo e($details['name']); ?></p>
    <p><strong>Cédula:</strong> <?php echo e($details['cedula']); ?></p>
    <p><strong>Correo:</strong> <?php echo e($details['email']); ?></p>
    <p><strong>Reporte:</strong> <?php echo e($details['report']); ?></p>
    <?php if(!empty($details['screenshot'])): ?>
        <p>Captura de pantalla adjunta.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aruizc01\carnetizador\resources\views/emails/support.blade.php ENDPATH**/ ?>