<div class="container-fluid pt-5">
    <div class="container">
        <div class="text-center pb-2">
            <p class="section-title px-5"><span class="px-2">Clases Populares</span></p>
            <h1 class="mb-4">Muestras de nuestra experiencia</h1>
        </div>
        <div class="row">
            <div class="col-lg-4 mb-5">
                <div class="card border-0 bg-light shadow-sm pb-2">
                    <img class="card-img-top mb-2" src="img/Antes.jpg" alt="">
                    <div class="card-body text-center">
                        <h4 class="card-title">A&ntilde;os de experiencia</h4>
                        <p class="card-text">Tenemos una basta experiencia formando l&iacute;deres para el futuro</p>
                    </div>
                    <div class="card-footer bg-transparent py-4 px-5">
                        
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-4 mb-5">
                <div class="card border-0 bg-light shadow-sm pb-2">
                    <img class="card-img-top mb-2" src="img/Jardin.jpg" alt="">
                    
                    <div class="card-footer bg-transparent py-4 px-5">
                        
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-4 mb-5">
                <div class="card border-0 bg-light shadow-sm pb-2">
                    <img class="card-img-top mb-2" src="img/Grado.jpg" alt="">
                    <div class="card-body text-center">
                        <h4 class="card-title">Promociones de grado</h4>
                        <p class="card-text">Celebramos las promociones de los alumnos con el orgullo de saber que ser&aacute;n grandes profesionales</p>
                    </div>
                    <div class="card-footer bg-transparent py-4 px-5">
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Class End -->